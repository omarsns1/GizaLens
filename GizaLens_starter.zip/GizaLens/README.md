# GizaLens

Independent student research prototype for Arabic historical document processing.

## Important scope note
The supplied handwritten Arabic dataset is used to prototype handwriting recognition. It is not established as Giza excavation material. Do not label its pages as Giza diaries.

## Run locally
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Current milestone
- Browse scanned pages
- Display available paired DOCX transcriptions
- Inspect automatic page/transcription matching

## Research principles
- Keep original images unchanged.
- Distinguish source text, machine output, and human corrections.
- Preserve document/page provenance.
- Do not publish archival images without checking their licence and permissions.
